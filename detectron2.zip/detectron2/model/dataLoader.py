from detectron2.config import get_cfg

class Model:

    @classmethod
    def Dataset(cls):
        cfg = get_cfg()
        dataset_config = cfg.DATASETS.TRAIN[0]
