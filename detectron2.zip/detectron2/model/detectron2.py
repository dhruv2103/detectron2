import os

import cv2
from detectron2 import model_zoo
from detectron2.config import get_cfg
# from detectron2.engine import DefaultTrainer
from detectron2.engine import DefaultPredictor
from detectron2.utils.logger import setup_logger
setup_logger()

from detectron2.utils.visualizer import Visualizer
from detectron2.data import MetadataCatalog, DatasetCatalog

import globalVariable as gv

class Model:

    @staticmethod
    def model():
        cfg = get_cfg()
        cfg.merge_from_file(model_zoo.get_config_file("COCO-Detection/faster_rcnn_R_50_FPN_3x.yaml"))
        cfg.DATALOADER.NUM_WORKERS = 2
        cfg.MODEL.WEIGHTS = model_zoo.get_checkpoint_url(
            "COCO-Detection/faster_rcnn_R_50_FPN_3x.yaml")  # initialize from model zoo
        cfg.MODEL.DEVICE = 'cpu'
        cfg.MODEL.ROI_HEADS.SCORE_THRESH_TEST = 0.7

        total_classes = MetadataCatalog.get(cfg.DATASETS.TRAIN[0]).thing_classes
        predictor = DefaultPredictor(cfg)

        return predictor, total_classes

    @staticmethod
    def predict(image):
        outputs = gv.model(image)
        pred_classes = outputs["instances"].pred_classes.tolist()
        pred_classes = [gv.total_classes[c] for c in pred_classes]
        pred_boxes = outputs["instances"].pred_boxes

        return pred_classes, pred_boxes

