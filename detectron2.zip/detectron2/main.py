import os
import cv2
import torch
import datetime as dt
from cv2.cv2 import CAP_PROP_FPS
from flask import Flask, send_file
from flask import request, jsonify
from flask_cors import CORS, cross_origin

from logger.logger import logger
from model.detectron2 import Model

import globalVariable as gv

ALLOWED_EXTENSIONS = {'mp4'}
upload_path = './uploads/'
tmp_path = './tmp/'
output_path = './outputs/'

frame_skip = {30: 15, 60: 20}

app = Flask(__name__)
cors = CORS(app)


def allowed_file(filename):
    """
        This Function checks whether file uploaded by User is allowed or not.

    :param filename: it is filename which has extension with it.
    :return: True/False (Whether file is allowed or not.)
    """

    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


@app.route('/findEntities', methods=['GET', 'POST'])
@cross_origin()
def findEntities():
    """
        Main Route for VideoAnalyzer from video using Detectron2.
    :return: returns Entities of PDF or IMAGE
    """

    if request.method == 'POST':
        file = request.files['file']
        if (file.filename != "") and allowed_file(file.filename):
            file_name = request.files['file'].filename
            file_path = os.path.join(upload_path, file_name)
            file.save(file_path)
            logger.info("File saved...!")

            try:
                metadata = {}
                last_frame_classes = []

                cap = cv2.VideoCapture(file_path)
                fps = cap.get(CAP_PROP_FPS)
                frame_count = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))

                print('fps = ' + str(fps))
                print('number of frames = ' + str(frame_count))
                duration = frame_count / fps
                print('duration (S) = ' + str(duration))
                minutes = int(duration / 60)
                seconds = duration % 60
                print('duration (M:S) = ' + str(minutes) + ':' + str(seconds))

                i = 0
                while cap.isOpened():
                    ret, frame = cap.read()
                    if ret:

                        seconds = int(i / fps)
                        minutes = int(seconds / 60)
                        hour = int(minutes / 60)
                        minutes = int(minutes % 60)
                        seconds = int(seconds % 60)

                        classes, _ = Model.predict(frame)

                        # metadata = {
                        #     "person": [
                        #         {
                        #             "start_time": dt.time(0,0,0),
                        #             "end_time": dt.time(0,0,2)
                        #         },
                        #         {
                        #             "start_time": dt.time(0,0,5),
                        #             "end_time": dt.time(0,0,8)
                        #         }
                        #     ],
                        #     "car": [
                        #         {
                        #             "start_time": dt.time(0, 0, 10),
                        #             "end_time": dt.time(0, 0, 20)
                        #         }
                        #     ]
                        # }

                        classes = set(classes)

                        for pred_class in classes:
                                if pred_class not in last_frame_classes:
                                    if pred_class not in metadata:
                                        metadata[pred_class] = [{'start_time': dt.time(hour, minutes, seconds).strftime("%H:%M:%S")}]
                                    else:
                                        metadata[pred_class].append({'start_time': dt.time(hour, minutes, seconds).strftime("%H:%M:%S")})

                        for e_class in last_frame_classes:
                            if e_class not in classes:
                                metadata[e_class][-1]['end_time'] = dt.time(hour, minutes, seconds).strftime("%H:%M:%S")

                        print("for frame : " + str(i) + ", " + str(len(classes)) + " objects were found.")
                        print(metadata)

                        if fps in frame_skip:
                            i = i + frame_skip[fps]

                        if i >= frame_count - fps:
                            for e_class in last_frame_classes:
                                metadata[e_class][-1]['end_time'] = dt.time(hour, minutes, seconds).strftime("%H:%M:%S")

                        last_frame_classes = classes

                        cap.set(cv2.CAP_PROP_POS_FRAMES, i)

                    else:
                        cap.release()
                        break

                print(metadata)

                # Closes all the frames
                cv2.destroyAllWindows()
                return jsonify({"status": "success", "meta-data": metadata}), 200
            except Exception as e:
                logger.exception(e)
                return jsonify({"status": "failed", "error": "Error occurred while processing File...!"}), 500


        else:
            logger.exception("In-appropriate File passed...!")
            return jsonify({"status": "failed", "error": "In-appropriate File passed...!"}), 500

    else:
        logger.warn("In-appropriate Request...!")
        return jsonify({"status": "failed", "error": "In-appropriate Request...!"}), 404


if __name__ == '__main__':
    os.mkdir(upload_path) if not os.path.isdir(upload_path) else None
    os.mkdir(tmp_path) if not os.path.isdir(tmp_path) else None

    TORCH_VERSION = ".".join(torch.__version__.split(".")[:2])
    CUDA_VERSION = torch.__version__.split("+")[-1]
    print("torch: ", TORCH_VERSION, "\ndevice: ", CUDA_VERSION)

    print("Loading Model from pretrained weights...!")
    gv.model, gv.total_classes = Model.model()
    print("Weights are loaded successfully...!")

    app.run(debug=False, host='0.0.0.0', port=5000)
