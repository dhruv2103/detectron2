import pymongo as pymongo
from src.app.config.configuration import train_config as config
import datetime
from pymongo import MongoClient


class DBUtil(object):
    connection = None

    @classmethod
    def default_parameter(cls, table_name):
        if table_name == "TrainingTracker":
            return config.db_default_master
        else:
            return config.other_default

    @classmethod
    def date_time(cls):
        return str(datetime.datetime.now())

    @classmethod
    def getConnection(cls):  # get connection for database connection and connection to database
        try:
            if cls.connection is not None:
                return cls.connection
            username = str(config.mongo_db_user)
            password_db = str(config.mongo_db_password)
            hostname = config.mongo_db_host
            dbSchema = str(config.mongo_db_name)
            port = int(str(config.mongo_db_port))
            mongo_auth_db = str(config.mongo_auth_db)
            print('------------', username, password_db, hostname, dbSchema, port, mongo_auth_db, '------------')
            mongoClient = MongoClient(host=hostname, port=port, username=username, password=password_db,
                                      authSource=mongo_auth_db)
            cls.connection = mongoClient[dbSchema]
            print(cls.connection)
        except Exception as e:
            print("Error while connecting To database : " + str(e))
            raise
        return cls.connection

    @classmethod
    def getData(cls, tableName, filterDict={}, projection=[], pageNumber=1, pageSize=100000,
                sort=['_id', pymongo.ASCENDING]):
        try:
            # print(filterDict)
            if cls.connection is None:
                cls.getConnection()

            skipValue = (pageNumber - 1) * pageSize
            limitValue = pageSize
            if projection:
                projection = {k: 1 for k in projection}
                records = cls.connection[tableName].find(filterDict,
                                                         projection).skip(skipValue).limit(limitValue).sort(*sort)
            else:
                records = cls.connection[tableName].find(filterDict).skip(skipValue).limit(limitValue).sort(*sort)
            result = []
            if records:
                for record in records:
                    record["_id"] = str(record["_id"])
                    result.append(record)
                return result
            else:
                return False
        except Exception as e:
            print(e)
            print("Exception in getData for " + tableName)
            raise

    @classmethod
    def insert(cls, tableName, data={}):
        try:
            if cls.connection is None:
                cls.getConnection()
            data = [data] if type(data) == dict else data
            response = cls.connection[tableName].insert_many(data)
            return True
        except Exception as e:
            print(e)
            print('Exception while loading the data for ' + tableName)
            raise

    @classmethod
    def update(cls, tableName, filter={}, data={}):
        try:
            if cls.connection is None:
                cls.getConnection()
            response = cls.connection[tableName].update(filter, {'$set': data}, upsert=False, multi=True)
            return list(response)
        except Exception as e:
            print("Exception while updating the data for " + tableName)
            print(e)
            raise

    @classmethod
    def upsert(cls, tableName, filter={}, data={}):
        try:
            if cls.connection is None:
                cls.getConnection()
            response = cls.connection[tableName].update(filter, {'$set': data}, upsert=True, multi=True)
            return list(response)
        except Exception as e:
            print("Exception while upserting the data for " + tableName)
            print(e)
            raise

    @classmethod
    def delete(cls, tableName, filter={}):
        try:
            if cls.connection is None:
                cls.getConnection()
            response = cls.connection[tableName].delete_one(filter)
            return response
        except Exception as e:
            print("Exception while upserting the data for " + tableName)
            print(e)
            raise
